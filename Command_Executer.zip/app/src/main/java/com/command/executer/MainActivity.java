package com.command.executer;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.*;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.appbar.AppBarLayout;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Calendar;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;
import android.content.Context;
import android.location.LocationManager;
import android.provider.Settings;
import androidx.appcompat.app.AppCompatActivity;
import android.location.Geocoder;
import android.location.Location;
import java.util.List;
import java.util.Locale;
import android.location.Address;


public class MainActivity extends AppCompatActivity {
	
	public final int REQ_CD_FP = 101;
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private double id = 0;
	private double download_test_progress_percent = 0;
	private String image_path = "";
	private String read = "";
	private String url = "";
	private HashMap<String, Object> map = new HashMap<>();
	private String admin = "";
	private double random = 0;
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear4;
	private WebView webview1;
	private LinearLayout linear5;
	private TextView executed_code;
	private LinearLayout linear12;
	private LinearLayout linear11;
	private LinearLayout download_test_progress_linear;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private LinearLayout linear10;
	private ImageView imageview1;
	private TextView textview1;
	private EditText network_ip;
	private Button button7;
	private EditText edittext2;
	private Button button6;
	private SeekBar seekbar2;
	private EditText package_name;
	private Button button1;
	private EditText read_file_path;
	private Button button2;
	private EditText edittext1;
	private Button button4;
	private EditText url_id;
	private Button load_url;
	private LinearLayout linear9;
	private LinearLayout download_test_title_linear;
	private LinearLayout download_test_message_linear;
	private LinearLayout linear3;
	private LinearLayout download_linear;
	private Button button5;
	private EditText download_test_title;
	private EditText download_test_message;
	private Button show_download_test_notification;
	private EditText command;
	private Button execute;
	private EditText download_url;
	private Button start_download;
	
	private AlertDialog.Builder system_dialog;
	private BluetoothConnect bluetooth;
	private BluetoothConnect.BluetoothConnectionListener _bluetooth_bluetooth_connection_listener;
	private Intent intent = new Intent();
	private Intent fp = new Intent(Intent.ACTION_GET_CONTENT);
	private Calendar calendar = Calendar.getInstance();
	private SharedPreferences account_type;
	private TimePickerDialog hp;
	private TimePickerDialog.OnTimeSetListener hp_listener;
	private SharedPreferences ReceiveData;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		linear4 = findViewById(R.id.linear4);
		webview1 = findViewById(R.id.webview1);
		webview1.getSettings().setJavaScriptEnabled(true);
		webview1.getSettings().setSupportZoom(true);
		linear5 = findViewById(R.id.linear5);
		executed_code = findViewById(R.id.executed_code);
		linear12 = findViewById(R.id.linear12);
		linear11 = findViewById(R.id.linear11);
		download_test_progress_linear = findViewById(R.id.download_test_progress_linear);
		linear6 = findViewById(R.id.linear6);
		linear7 = findViewById(R.id.linear7);
		linear8 = findViewById(R.id.linear8);
		linear10 = findViewById(R.id.linear10);
		imageview1 = findViewById(R.id.imageview1);
		textview1 = findViewById(R.id.textview1);
		network_ip = findViewById(R.id.network_ip);
		button7 = findViewById(R.id.button7);
		edittext2 = findViewById(R.id.edittext2);
		button6 = findViewById(R.id.button6);
		seekbar2 = findViewById(R.id.seekbar2);
		package_name = findViewById(R.id.package_name);
		button1 = findViewById(R.id.button1);
		read_file_path = findViewById(R.id.read_file_path);
		button2 = findViewById(R.id.button2);
		edittext1 = findViewById(R.id.edittext1);
		button4 = findViewById(R.id.button4);
		url_id = findViewById(R.id.url_id);
		load_url = findViewById(R.id.load_url);
		linear9 = findViewById(R.id.linear9);
		download_test_title_linear = findViewById(R.id.download_test_title_linear);
		download_test_message_linear = findViewById(R.id.download_test_message_linear);
		linear3 = findViewById(R.id.linear3);
		download_linear = findViewById(R.id.download_linear);
		button5 = findViewById(R.id.button5);
		download_test_title = findViewById(R.id.download_test_title);
		download_test_message = findViewById(R.id.download_test_message);
		show_download_test_notification = findViewById(R.id.show_download_test_notification);
		command = findViewById(R.id.command);
		execute = findViewById(R.id.execute);
		download_url = findViewById(R.id.download_url);
		start_download = findViewById(R.id.start_download);
		system_dialog = new AlertDialog.Builder(this);
		bluetooth = new BluetoothConnect(this);
		fp.setType("image/*");
		fp.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		account_type = getSharedPreferences("UserData", Activity.MODE_PRIVATE);
		hp = new TimePickerDialog(this, hp_listener, Calendar.HOUR_OF_DAY, Calendar.MINUTE, false);
		ReceiveData = getSharedPreferences("command", Activity.MODE_PRIVATE);
		
		webview1.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				url = _url;
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				url = _url;
				super.onPageFinished(_param1, _param2);
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		button7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				webview1.setVisibility(View.VISIBLE);
				webview1.loadUrl(network_ip.getText().toString());
				network_ip.setText("");
				linear12.setVisibility(View.GONE);
			}
		});
		
		button6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				System.out.println(edittext2.getText().toString());
			}
		});
		
		seekbar2.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			@Override
			public void onProgressChanged(SeekBar _param1, int _param2, boolean _param3) {
				final int _progressValue = _param2;
				download_test_progress_percent = _progressValue;
			}
			
			@Override
			public void onStartTrackingTouch(SeekBar _param1) {
				
			}
			
			@Override
			public void onStopTrackingTouch(SeekBar _param2) {
				
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (button1.getText().toString().equals("Unistall")) {
					Uri packageURI = Uri.parse("package:".concat(package_name.getText().toString())); Intent uninstallIntent = new Intent(Intent.ACTION_DELETE, packageURI); startActivity(uninstallIntent);
					linear6.setVisibility(View.GONE);
				}
				if (button1.getText().toString().equals("Open")) {
					if (package_name.getText().toString().equals("com.google.android.documentsui")) {
						intent.setClass(getApplicationContext(), Filemanager.class);
						startActivity(intent);
					} else {
						try{
							Intent launchIntent = getPackageManager().getLaunchIntentForPackage(package_name.getText().toString());  { startActivity(launchIntent);}
							linear6.setVisibility(View.GONE);
							button1.setText("Unistall");
						}catch(Exception e){
							String error = e.toString();
							executed_code.setText("Error while opening app/invalid name, please try other app/retry again\nerror: ".concat(error));
						}
					}
				}
			}
		});
		
		read_file_path.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				read = FileUtil.readFile(read_file_path.getText().toString());
				linear7.setVisibility(View.GONE);
				SketchwareUtil.showMessage(getApplicationContext(), "path/file path readed sucessfully ");
				executed_code.setText(read);
			}
		});
		
		button4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), edittext1.getText().toString());
				linear8.setVisibility(View.GONE);
			}
		});
		
		load_url.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (load_url.getText().toString().equals("load")) {
					linear10.setVisibility(View.GONE);
					webview1.setVisibility(View.VISIBLE);
					webview1.loadUrl(load_url.getText().toString());
				}
				if (load_url.getText().toString().equals("load external")) {
					linear10.setVisibility(View.GONE);
					intent.setAction(Intent.ACTION_VIEW);
					intent.setData(Uri.parse(url_id.getText().toString()));
					startActivity(intent);
				}
			}
		});
		
		button5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				command.setText("");
			}
		});
		
		show_download_test_notification.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				final Context context = getApplicationContext();
				
				
				NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
				
				
				
				androidx.core.app.NotificationCompat
				.Builder builder; 
				
				int notificationId = (int)1;
				String channelId = "channel-01";
				String channelName = "Channel Name";
				int importance = NotificationManager.IMPORTANCE_HIGH;
				
				if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
					NotificationChannel mChannel = new NotificationChannel(
					channelId, channelName, importance);
					notificationManager.createNotificationChannel(mChannel);
				}
				
				androidx.core.app.NotificationCompat
				.Builder mBuilder = new androidx.core.app.NotificationCompat
				.Builder(context, channelId)
				
				.setSmallIcon(android.R.drawable.stat_sys_download)
				.setTicker("")
				.setContentTitle(download_test_title.getText().toString())
				.setContentText(download_test_message.getText().toString())
				.setProgress((int)100,(int)download_test_progress_percent, false);
				
				
				notificationManager.notify(notificationId, mBuilder.build());
				download_test_progress_linear.setVisibility(View.GONE);
				download_test_message_linear.setVisibility(View.GONE);
				download_test_title_linear.setVisibility(View.GONE);
				linear3.setVisibility(View.VISIBLE);
				executed_code.setText("to remove the notification just remove and enable the notification permission again");
			}
		});
		
		execute.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (command.getText().toString().equals("webview:status.shutdown")) {
					webview1.setVisibility(View.GONE);
					linear4.setVisibility(View.VISIBLE);
				}
				if (command.getText().toString().equals("cd:webview.start")) {
					webview1.setVisibility(View.VISIBLE);
					webview1.loadUrl("https://google.com");
					linear4.setVisibility(View.GONE);
				}
				if (command.getText().toString().equals("cmd:help")) {
					executed_code.setText("cd:webview.start \nwill start an internet view\nwebview:status.shutdown\nwill finish the internet view");
				}
				if (command.getText().toString().equals("cd:shutdown")) {
					finishAffinity();
				}
				if (command.getText().toString().equals("system.startDownload")) {
					linear4.setVisibility(View.GONE);
					webview1.setVisibility(View.INVISIBLE);
					download_linear.setVisibility(View.VISIBLE);
				}
				if (command.getText().toString().equals("system.shutdown")) {
					finishAffinity();
				}
				if (command.getText().toString().equals("system.startTestDownload")) {
					linear3.setVisibility(View.GONE);
					download_test_progress_linear.setVisibility(View.VISIBLE);
					download_test_title_linear.setVisibility(View.VISIBLE);
					download_test_message_linear.setVisibility(View.VISIBLE);
				}
				if (command.getText().toString().equals("system.activateBluetooth")) {
					bluetooth.activateBluetooth();
				}
				if (command.getText().toString().equals("system.disableBluetooth")) {
					android.bluetooth.BluetoothAdapter adapter = android.bluetooth.BluetoothAdapter.getDefaultAdapter();
					adapter.disable();
				}
				if (command.getText().toString().equals("system.connect (\"android\") (\"flashlight\")")) {
					android.hardware.camera2.CameraManager cameraManager = (android.hardware.camera2.CameraManager) getSystemService(Context.CAMERA_SERVICE);
					try {
						String cameraId = cameraManager.getCameraIdList()[0]; cameraManager.setTorchMode(cameraId, true); } catch (android.hardware.camera2.CameraAccessException e) { }
				}
				if (command.getText().toString().equals("system.disconnect (\"android\") (\"flashlight\")")) {
					android.hardware.camera2.CameraManager cameraManager = (android.hardware.camera2.CameraManager) getSystemService(Context.CAMERA_SERVICE);
					try {
						String cameraId = cameraManager.getCameraIdList()[0]; cameraManager.setTorchMode(cameraId, false); } catch (android.hardware.camera2.CameraAccessException e) { }
				}
				if (command.getText().toString().equals("system.getname")) {
					executed_code.setText(getApplicationContext().getPackageName());
				}
				if (command.getText().toString().equals("system.boot")) {
					intent.setClass(getApplicationContext(), BootActivity.class);
					startActivity(intent);
				}
				if (command.getText().toString().equals("system.connect (\"android\") (\"request.system_PackageManagerAndroid\") (\"Unistall\")")) {
					linear6.setVisibility(View.VISIBLE);
				}
				if (command.getText().toString().equals("system.landscape")) {
					setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
				}
				if (command.getText().toString().equals("system.portrait")) {
					setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
				}
				if (command.getText().toString().equals("system.name")) {
					((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", getApplicationContext().getPackageName()));
				}
				if (command.getText().toString().equals("system.keepScreen (\"On\")")) {
					getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
					SketchwareUtil.showMessage(getApplicationContext(), "enabled sucessfully");
				}
				if (command.getText().toString().equals("system.request (\"storage\") (\"get_every_path\") (\"to_app\")")) {
					executed_code.setText(FileUtil.getExternalStorageDir().substring((int)(1), (int)(FileUtil.getExternalStorageDir().length())));
				}
				if (command.getText().toString().equals("cd:/system_apps")) {
					intent.setClass(getApplicationContext(), SystemAppsActivity.class);
					startActivity(intent);
				}
				if (command.getText().toString().equals("system.keepScreen (\"Off\")")) {
					getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
					SketchwareUtil.showMessage(getApplicationContext(), "disabled sucessfully ");
				}
				if (command.getText().toString().equals("webview:back")) {
					webview1.goBack();
				}
				if (command.getText().toString().equals("webview:forward")) {
					webview1.goForward();
				}
				if (command.getText().toString().equals("webview:SetCancelListener (\"On_Loading_Progress\")")) {
					webview1.stopLoading();
				}
				if (command.getText().toString().equals("system.check (\"Device_is_Rooted\")")) {
					try {
						
						Runtime.getRuntime().exec("su"); 
						
						executed_code.setText("your device is rooted");
						
					} catch (Exception e ) {
						
						executed_code.setText("your device is not rooted");
						
					}
				}
				if (command.getText().toString().equals("cd:math (\"Pi\")")) {
					executed_code.setText(String.valueOf(Math.PI));
				}
				if (command.getText().toString().equals("cd:android.request (\"pick_image\")")) {
					startActivityForResult(fp, REQ_CD_FP);
				}
				if (command.getText().toString().equals("system.connect (\"bluetooth\")")) {
					intent.setClass(getApplicationContext(), BluetoothActivity.class);
					startActivity(intent);
				}
				if (command.getText().toString().equals("system.setRequestListener (\"Read Path\")")) {
					linear7.setVisibility(View.VISIBLE);
				}
				if (command.getText().toString().equals("cd:android.request (\"Get_Build_Hardware\")")) {
					SketchwareUtil.showMessage(getApplicationContext(), Build.HARDWARE);
				}
				if (command.getText().toString().equals("cd:android.request (\"Get_Build_Host\")")) {
					SketchwareUtil.showMessage(getApplicationContext(), Build.HOST);
				}
				if (command.getText().toString().equals("cd:math (\"Euler indentify\")")) {
					executed_code.setText(String.valueOf(Math.E));
				}
				if (command.getText().toString().equals("cd:youtube")) {
					intent.setAction(Intent.ACTION_VIEW);
					intent.setData(Uri.parse("https://youtube.com/"));
					startActivity(intent);
				}
				if (command.getText().toString().equals("cd:hello")) {
					SketchwareUtil.showMessage(getApplicationContext(), "hello");
				}
				if (command.getText().toString().equals("set (\"CD\") to (\"Toast\")")) {
					linear8.setVisibility(View.VISIBLE);
				}
				if (command.getText().toString().equals("webview:url")) {
					if (webview1.getVisibility() == View.GONE) {
						executed_code.setText("start webview first");
					} else {
						command.setText("the url is ".concat(url));
						execute.setText("Copy");
						execute.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View _view) {
								if (execute.getText().toString().equals("Copy")) {
									((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", url));
									execute.setText("Execute");
								}
							}
						});
					}
				}
				if (command.getText().toString().equals(url)) {
					intent.setAction(Intent.ACTION_VIEW);
					intent.setData(Uri.parse(url));
					startActivity(intent);
				}
				if (command.getText().toString().equals("")) {
					((EditText)command).setError("put a command");
				}
				if (command.getText().toString().equals("request (\"admin\")")) {
					_request("admin", "popup action");
				}
				if (command.getText().toString().equals("request (\"admin\") (\"version\")")) {
					_request("admin", "version");
				}
				if (command.getText().toString().equals("request (\"admin\") (\"user\")")) {
					_request("user", "set (\"user\") to user (\"admin\")");
				}
				if (command.getText().toString().equals("checkfor (\"userType\") (\"admin\")")) {
					if (account_type.getString("userType", "").equals("admin")) {
						executed_code.setText("you are an admin");
					} else {
						executed_code.setText("you are not an admin");
					}
				}
				if (command.getText().toString().equals("request (\"user\") (\"admin\")")) {
					_request("admin", "set (\"admin\") to user (\"user\")");
				}
				if (command.getText().toString().equals("terminal")) {
					intent.setClass(getApplicationContext(), TerminalActivity.class);
					startActivity(intent);
				}
				if (command.getText().toString().equals("system.connect (\"android\") (\"request.system_PackageManagerAndroid\") (\"Open\")")) {
					linear6.setVisibility(View.VISIBLE);
					button1.setText("Open");
				}
				if (command.getText().toString().equals("request (\"pick\") (\"image\")")) {
					_request("admin", "files (\"action.PICK\") (\"filetype=IMAGE\")");
				}
				if (command.getText().toString().equals("1÷0")) {
					try{
						executed_code.setText(String.valueOf((long)(1 / 0)));
					}catch(Exception e){
						executed_code.setText("you cannot divide by zero");
					}
				}
				if (command.getText().toString().equals("hourpicker.show")) {
					hp.show();
				}
				if (command.getText().toString().equals("cd:randomNumber") || command.getText().toString().contains("cd:randomNumber")) {
					try{
						random = SketchwareUtil.getRandom((int)(0), (int)(9223372036854775.807d));
						executed_code.setText(String.valueOf((long)(random)));
					}catch(Exception e){
						String error = e.toString();
						random = SketchwareUtil.getRandom((int)(0), (int)(4294967.295d));
						executed_code.setText(String.valueOf((long)(random)).concat("".concat(error)));
					}
				}
				if (command.getText().toString().equals("Ce.getDisplayWidthPixels") || command.getText().toString().contains("Ce.getDisplayWidthPixels")) {
					executed_code.setText(String.valueOf((long)(SketchwareUtil.getDisplayWidthPixels(getApplicationContext()))));
				}
				if (command.getText().toString().equals("Ce.getDisplayHeightPixels")) {
					executed_code.setText(String.valueOf((long)(SketchwareUtil.getDisplayHeightPixels(getApplicationContext()))));
				}
				if (command.getText().toString().equals("system.print") || command.getText().toString().contains("system.print")) {
					linear11.setVisibility(View.VISIBLE);
				}
				if (command.getText().toString().equals("cd:randomNumber (limit:Pi)") || command.getText().toString().contains("cd:randomNumber (limit:pi)")) {
					random = SketchwareUtil.getRandom((int)(0), (int)(Math.PI));
					executed_code.setText(String.valueOf(random));
				}
				if (command.getText().toString().equals("cd:randomNumber (limit:e)") || command.getText().toString().contains("cd:randomNumber (limit:e)")) {
					random = SketchwareUtil.getRandom((int)(0), (int)(Math.E));
					executed_code.setText(String.valueOf(random));
				}
				if (command.getText().toString().equals("crash") || command.getText().toString().contains("crash")) {
					SketchwareUtil.showMessage(getApplicationContext(), "Crashed Sucessfully");
					random = 1 / 0;
				}
				if (command.getText().toString().equals("cd:android.request (\"Get_id_host\")") || command.getText().toString().contains("cd:android.request (\"Get_id_host\")")) {
					executed_code.setText(Build.ID);
				}
				if (command.getText().toString().equals("system.activateGPS") || command.getText().toString().contains("system.activateGPS")) {
					final LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
					
					if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
						executed_code.setText("❌ GPS Disabled");
						Intent intent = getPackageManager().getLaunchIntentForPackage("com.command.executer");
						if (intent != null) {
							startActivity(intent);
						} else {
							startActivity(new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS));
						}
					} else {
						executed_code.setText("✅ GPS Active (Requesting Location...)");
						
						android.location.LocationListener listener = new android.location.LocationListener() {
							@Override
							public void onLocationChanged(Location loc) {
								try {
									Geocoder geocoder = new Geocoder(getApplicationContext(), Locale.getDefault());
									List<Address> addresses = geocoder.getFromLocation(loc.getLatitude(), loc.getLongitude(), 1);
									
									if (addresses != null && !addresses.isEmpty()) {
										Address ad = addresses.get(0);
										
										String street = ad.getThoroughfare() != null ? ad.getThoroughfare() : "Unknown Street";
										String neighborhood = ad.getSubLocality() != null ? ad.getSubLocality() : "Unknown Neighborhood";
										String city = ad.getLocality() != null ? ad.getLocality() : "Unknown City";
										String state = ad.getAdminArea() != null ? ad.getAdminArea() : "Unknown State";
										String country = ad.getCountryName() != null ? ad.getCountryName() : "Unknown Country";
										
										// Lógica para detectar o Continente baseado no Código do País (ISO)
										String countryCode = ad.getCountryCode(); // Ex: BR, US, FR
										String continent = "Unknown Continent";
										
										if (countryCode != null) {
											Locale l = new Locale("", countryCode);
											// O Java mapeia o display name, mas para o continente usamos uma lógica simples de ISO:
											String iso = countryCode.toUpperCase();
											// Mapeamento simplificado (Exemplos comuns):
											if ("BR|AR|CL|CO|PE|UY|PY|BO|EC|VE|GY|SR".contains(iso)) continent = "South America";
											else if ("US|CA|MX".contains(iso)) continent = "North America";
											else if ("PT|ES|FR|DE|IT|GB|UK|RU".contains(iso)) continent = "Europe";
											else if ("CN|JP|IN|KR".contains(iso)) continent = "Asia";
											else if ("ZA|NG|EG".contains(iso)) continent = "Africa";
											else if ("AU|NZ".contains(iso)) continent = "Oceania";
											else continent = "International Territory"; 
										}
										
										String info = "✅ " + street + ", " + neighborhood + ", " + city + ", " + state + ", " + country + ", " + continent;
										executed_code.setText(info);
									}
									lm.removeUpdates(this);
								} catch (Exception e) {
									executed_code.setText("✅ GPS Active (Geocoder Error)");
								}
							}
							@Override public void onStatusChanged(String p, int s, Bundle e) {}
							@Override public void onProviderEnabled(String p) {}
							@Override public void onProviderDisabled(String p) {}
						};
						
						try {
							lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, listener);
							lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, listener);
						} catch (SecurityException e) {
							executed_code.setText("❌ Permission Denied");
						}
					}
					
				}
				if (command.getText().toString().equals("ls commands") || command.getText().toString().contains("ls commands")) {
					StringBuilder help = new StringBuilder();
					help.append("--- AVAILABLE COMMANDS ---\n");
					help.append("🌐 WEB: cd:webview.start, webview:url, webview:status.shutdown, webview:back, cd:youtube\n\n");
					help.append("🛠️ SYS: system.activateBluetooth, system.disableBluetooth, system.connect (\"flashlight\"), system.activateGPS, system.check (\"Device_is_Rooted\")\n\n");
					help.append("📱 UI: system.landscape, system.portrait, system.keepScreen (\"On/Off\"), system.boot, terminal\n\n");
					help.append("🔢 MATH: cd:math (\"Pi\"), cd:math (\"Euler\"), cd:randomNumber\n\n");
					help.append("📂 DATA: system.startDownload, system.request (\"storage\"), system.getname\n\n");
					help.append("🛡️ ADMIN: checkfor (\"userType\"), request (\"admin\"), system.shutdown, crash\n");
					help.append("--------------------------");
					
					executed_code.setText(help.toString());
					
				}
				if (command.getText().toString().equals("webview:gateway") || command.getText().toString().contains("webview:gateway")) {
					linear12.setVisibility(View.VISIBLE);
				}
				if (command.getText().toString().equals("system.restart") || command.getText().toString().contains("system.restart")) {
					recreate();
				}
			}
		});
		
		start_download.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				webview1.setVisibility(View.INVISIBLE);
				system_dialog.setTitle("which website?");
				system_dialog.setMessage("if u want to start from apk pure press apk pure (must be a word before searching for it), if u want to download by other link press other link, if u dont want to download then press cancel button. actions to download are manual not automatic");
				system_dialog.setPositiveButton("apk pure", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						if (download_url.getText().toString().contains("https://") || download_url.getText().toString().contains("http://")) {
							webview1.loadUrl(download_url.getText().toString());
						}
						else {
							webview1.loadUrl("https://www.google.com/search?ie=UTF-8&client=ms-android-samsung&source=android-browser&q=".concat(download_url.getText().toString()));
						}
						webview1.setVisibility(View.VISIBLE);
						download_linear.setVisibility(View.GONE);
						linear4.setVisibility(View.VISIBLE);
					}
				});
				system_dialog.setNegativeButton("other link", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						webview1.setVisibility(View.VISIBLE);
						webview1.loadUrl(download_url.getText().toString());
						download_linear.setVisibility(View.GONE);
						linear4.setVisibility(View.VISIBLE);
					}
				});
				system_dialog.setNeutralButton("cancel", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						webview1.setVisibility(View.GONE);
						download_linear.setVisibility(View.GONE);
						linear4.setVisibility(View.VISIBLE);
					}
				});
			}
		});
		
		_bluetooth_bluetooth_connection_listener = new BluetoothConnect.BluetoothConnectionListener() {
			@Override
			public void onConnected(String _param1, HashMap<String, Object> _param2) {
				final String _tag = _param1;
				final HashMap<String, Object> _deviceData = _param2;
				
			}
			
			@Override
			public void onDataReceived(String _param1, byte[] _param2, int _param3) {
				final String _tag = _param1;
				final String _data = new String(_param2, 0, _param3);
				
			}
			
			@Override
			public void onDataSent(String _param1, byte[] _param2) {
				final String _tag = _param1;
				final String _data = new String(_param2);
				
			}
			
			@Override
			public void onConnectionError(String _param1, String _param2, String _param3) {
				final String _tag = _param1;
				final String _connectionState = _param2;
				final String _errorMessage = _param3;
				
			}
			
			@Override
			public void onConnectionStopped(String _param1) {
				final String _tag = _param1;
				
			}
		};
		
		hp_listener = new TimePickerDialog.OnTimeSetListener() {
			@Override
			public void onTimeSet(TimePicker _timePicker, int _hour, int _minute) {
				executed_code.setText("hour set to ".concat(String.valueOf((long)(_hour)).concat(":".concat(String.valueOf((long)(_minute)).concat(" AM/PM")))));
				SketchwareUtil.showMessage(getApplicationContext(), "hour set to ".concat(String.valueOf((long)(_hour)).concat(":".concat(String.valueOf((long)(_minute)).concat(" AM/PM")))));
			}
		};
	}
	
	private void initializeLogic() {
		webview1.setVisibility(View.GONE);
		download_linear.setVisibility(View.GONE);
		webview1.setDownloadListener(new DownloadListener() {
			public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
				Intent intent = new Intent(Intent.ACTION_VIEW);
				intent.setData(Uri.parse(url));
				startActivity (intent);
			}
		});
		download_test_progress_linear.setVisibility(View.GONE);
		download_test_message_linear.setVisibility(View.GONE);
		download_test_title_linear.setVisibility(View.GONE);
		imageview1.setVisibility(View.GONE);
		linear6.setVisibility(View.GONE);
		linear7.setVisibility(View.GONE);
		linear8.setVisibility(View.GONE);
		linear10.setVisibility(View.GONE);
		linear11.setVisibility(View.GONE);
		linear12.setVisibility(View.GONE);
		if (account_type.getString("userType", "").equals("admin")) {
			executed_code.setText("you are an admin");
		} else {
			executed_code.setText("you are an user");
		}
		if (ReceiveData.getString("command", "").equals("system.startDownload")) {
			command.setText("system.startDownload");
			ReceiveData.edit().putString("command", "").commit();
			execute.performClick();
			executed_code.setText("action completed sucessfully ");
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_FP:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				image_path = _filePath.get((int)(0));
				imageview1.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(image_path, 1024, 1024));
				imageview1.setVisibility(View.VISIBLE);
			}
			else {
				imageview1.setVisibility(View.GONE);
				executed_code.setText("you cancelled\nID: ACTION_CANCELLED");
			}
			break;
			default:
			break;
		}
	}
	
	public void _request(final String _user, final String _code) {
		if (_user.equals("admin") && _code.equals("popup action")) {
			system_dialog.setTitle("Admin");
			system_dialog.setMessage("which action admin should do?");
			system_dialog.setPositiveButton("load url", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					system_dialog.setTitle("choose");
					system_dialog.setMessage("from the app or from the device? (by using browser)");
					system_dialog.setPositiveButton("app", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							linear10.setVisibility(View.VISIBLE);
							load_url.setText("load");
						}
					});
					system_dialog.setNegativeButton("device", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							linear10.setVisibility(View.VISIBLE);
							load_url.setText("load external");
						}
					});
					system_dialog.setNeutralButton("Dismiss", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							
						}
					});
					system_dialog.create().show();
				}
			});
			system_dialog.setNegativeButton("toast test & notification test", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					SketchwareUtil.showMessage(getApplicationContext(), "example");
					_notification("Admin Notification Sender", "here is the notification you requested");
				}
			});
			system_dialog.setNeutralButton("download", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface _dialog, int _which) {
					download_linear.setVisibility(View.VISIBLE);
				}
			});
			system_dialog.create().show();
		}
		if (_user.equals("admin") && _code.equals("version")) {
			executed_code.setText("app version is 1.0 beta");
		}
		if (_user.equals("admin") && _code.equals("files (\"action.PICK\") (\"filetype=IMAGE\")")) {
			startActivityForResult(fp, REQ_CD_FP);
		}
		if (_user.equals("user") && _code.equals("set (\"user\") to user (\"admin\")")) {
			account_type.edit().putString("userType", "admin").commit();
			executed_code.setText("you are an admin now");
		}
		if (_user.equals("admin") && _code.equals("set (\"admin\") to user (\"user\")")) {
			account_type.edit().putString("userType", "user").commit();
			executed_code.setText("you are an user");
		}
	}
	
	
	public void _notification(final String _title, final String _message) {
		// Generate unique ID for each notification
		int notificationId = (int) System.currentTimeMillis();
		
		// Channel setup (Android 8+)
		String channelId = "my_channel";
		if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
			android.app.NotificationChannel channel = new android.app.NotificationChannel(
			channelId,
			"Alerts",
			android.app.NotificationManager.IMPORTANCE_DEFAULT
			);
			getSystemService(android.app.NotificationManager.class).createNotificationChannel(channel);
		}
		
		// Create notification
		androidx.core.app.NotificationCompat.Builder builder = new androidx.core.app.NotificationCompat.Builder(this, channelId)
		.setSmallIcon(getApplicationInfo().icon != 0 ? getApplicationInfo().icon : android.R.drawable.ic_dialog_info)
		.setContentTitle(_title)
		.setContentText(_message)
		.setPriority(androidx.core.app.NotificationCompat.PRIORITY_DEFAULT)
		.setAutoCancel(true);
		
		// Show notification
		getSystemService(android.app.NotificationManager.class).notify(notificationId, builder.build());
	}
	
}