package com.command.executer;

import android.animation.*;
import android.app.*;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayout.OnTabSelectedListener;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class BluetoothActivity extends AppCompatActivity {
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	
	private LinearLayout linear2;
	private ImageView imageview1;
	private Button button1;
	private TabLayout tablayout1;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private LinearLayout linear8;
	private LinearLayout linear5;
	private Button button2;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private TextView tag;
	private TextView tag_id;
	private TextView textview1;
	private TextView textview2;
	private TextView textview5;
	private TextView textview6;
	private TextView textview3;
	private TextView textview4;
	private EditText edittext1;
	private Button button3;
	
	private BluetoothConnect bluetooth;
	private BluetoothConnect.BluetoothConnectionListener _bluetooth_bluetooth_connection_listener;
	private AlertDialog.Builder dialog;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.bluetooth);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		linear2 = findViewById(R.id.linear2);
		imageview1 = findViewById(R.id.imageview1);
		button1 = findViewById(R.id.button1);
		tablayout1 = findViewById(R.id.tablayout1);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		linear8 = findViewById(R.id.linear8);
		linear5 = findViewById(R.id.linear5);
		button2 = findViewById(R.id.button2);
		linear6 = findViewById(R.id.linear6);
		linear7 = findViewById(R.id.linear7);
		tag = findViewById(R.id.tag);
		tag_id = findViewById(R.id.tag_id);
		textview1 = findViewById(R.id.textview1);
		textview2 = findViewById(R.id.textview2);
		textview5 = findViewById(R.id.textview5);
		textview6 = findViewById(R.id.textview6);
		textview3 = findViewById(R.id.textview3);
		textview4 = findViewById(R.id.textview4);
		edittext1 = findViewById(R.id.edittext1);
		button3 = findViewById(R.id.button3);
		bluetooth = new BluetoothConnect(this);
		dialog = new AlertDialog.Builder(this);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				bluetooth.activateBluetooth();
				textview6.setText(bluetooth.getRandomUUID());
			}
		});
		
		tablayout1.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
			@Override
			public void onTabSelected(TabLayout.Tab tab) {
				final int _position = tab.getPosition();
				if (_position == 0) {
					linear3.setVisibility(View.VISIBLE);
					linear4.setVisibility(View.VISIBLE);
					linear5.setVisibility(View.GONE);
					linear6.setVisibility(View.GONE);
					linear7.setVisibility(View.GONE);
					linear8.setVisibility(View.VISIBLE);
				}
				if (_position == 1) {
					linear3.setVisibility(View.GONE);
					linear4.setVisibility(View.GONE);
					linear5.setVisibility(View.VISIBLE);
					linear6.setVisibility(View.GONE);
					linear7.setVisibility(View.GONE);
					linear8.setVisibility(View.GONE);
				}
				if (_position == 2) {
					linear3.setVisibility(View.GONE);
					linear4.setVisibility(View.GONE);
					linear5.setVisibility(View.GONE);
					linear6.setVisibility(View.VISIBLE);
					linear7.setVisibility(View.VISIBLE);
					linear8.setVisibility(View.GONE);
				}
			}
			
			@Override
			public void onTabUnselected(TabLayout.Tab tab) {
				final int _position = tab.getPosition();
				
			}
			
			@Override
			public void onTabReselected(TabLayout.Tab tab) {
				final int _position = tab.getPosition();
				
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				bluetooth.stopConnection(_bluetooth_bluetooth_connection_listener, tag_id.getText().toString());
			}
		});
		
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				bluetooth.sendData(_bluetooth_bluetooth_connection_listener, edittext1.getText().toString(), tag_id.getText().toString());
			}
		});
		
		_bluetooth_bluetooth_connection_listener = new BluetoothConnect.BluetoothConnectionListener() {
			@Override
			public void onConnected(String _param1, HashMap<String, Object> _param2) {
				final String _tag = _param1;
				final HashMap<String, Object> _deviceData = _param2;
				tag_id.setText(_tag);
				bluetooth.readyConnection(_bluetooth_bluetooth_connection_listener, _tag);
			}
			
			@Override
			public void onDataReceived(String _param1, byte[] _param2, int _param3) {
				final String _tag = _param1;
				final String _data = new String(_param2, 0, _param3);
				tag_id.setText(_tag);
				textview2.setText(_data);
			}
			
			@Override
			public void onDataSent(String _param1, byte[] _param2) {
				final String _tag = _param1;
				final String _data = new String(_param2);
				textview4.setText(_data);
				tag_id.setText(_tag);
			}
			
			@Override
			public void onConnectionError(String _param1, String _param2, String _param3) {
				final String _tag = _param1;
				final String _connectionState = _param2;
				final String _errorMessage = _param3;
				dialog.setTitle("error");
				dialog.setMessage(_errorMessage);
				dialog.setPositiveButton("see connection state", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						SketchwareUtil.showMessage(getApplicationContext(), _connectionState);
					}
				});
				dialog.setNegativeButton("see tag", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						SketchwareUtil.showMessage(getApplicationContext(), _tag);
					}
				});
				dialog.create().show();
			}
			
			@Override
			public void onConnectionStopped(String _param1) {
				final String _tag = _param1;
				SketchwareUtil.showMessage(getApplicationContext(), "connection stopped, the tag is");
				SketchwareUtil.showMessage(getApplicationContext(), _tag);
			}
		};
	}
	
	private void initializeLogic() {
		tablayout1.addTab(tablayout1.newTab().setText("received data"));
		tablayout1.addTab(tablayout1.newTab().setText("sended data"));
		tablayout1.addTab(tablayout1.newTab().setText("send data"));
	}
	
}