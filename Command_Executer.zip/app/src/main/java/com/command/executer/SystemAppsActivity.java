package com.command.executer;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.appbar.AppBarLayout;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class SystemAppsActivity extends AppCompatActivity {
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	
	private ScrollView vscroll3;
	private LinearLayout linear17;
	private LinearLayout linear18;
	private LinearLayout linear19;
	private LinearLayout linear20;
	private LinearLayout linear21;
	private LinearLayout linear22;
	private LinearLayout linear23;
	private LinearLayout linear24;
	private LinearLayout linear25;
	private LinearLayout linear26;
	private LinearLayout linear27;
	private LinearLayout linear28;
	private LinearLayout linear29;
	private LinearLayout linear30;
	private LinearLayout linear31;
	private LinearLayout linear32;
	private LinearLayout linear36;
	private LinearLayout linear37;
	private LinearLayout linear38;
	private LinearLayout linear39;
	private LinearLayout linear41;
	private LinearLayout linear42;
	private LinearLayout linear43;
	private ImageView imageview11;
	private TextView textview1;
	private ImageView imageview12;
	private TextView textview2;
	private ImageView imageview13;
	private TextView textview3;
	private ImageView imageview14;
	private TextView textview4;
	private ImageView imageview15;
	private TextView textview5;
	private ImageView imageview16;
	private TextView textview6;
	private ImageView imageview17;
	private TextView textview7;
	private ImageView imageview18;
	private TextView textview8;
	private ImageView imageview19;
	private TextView textview9;
	private ImageView imageview20;
	private TextView textview10;
	private ImageView imageview21;
	private TextView textview11;
	private ImageView imageview22;
	private TextView textview12;
	private ImageView imageview23;
	private TextView textview13;
	private ImageView imageview24;
	private TextView textview14;
	private ImageView imageview25;
	private TextView textview15;
	private ImageView imageview28;
	private TextView textview16;
	private ImageView imageview27;
	private TextView textview17;
	private ImageView imageview26;
	private TextView textview18;
	private ImageView imageview29;
	private TextView textview19;
	private ImageView imageview30;
	private TextView textview20;
	private ImageView imageview31;
	private TextView textview21;
	private ImageView imageview32;
	private TextView textview22;
	
	private Intent intent = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.system_apps);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		vscroll3 = findViewById(R.id.vscroll3);
		linear17 = findViewById(R.id.linear17);
		linear18 = findViewById(R.id.linear18);
		linear19 = findViewById(R.id.linear19);
		linear20 = findViewById(R.id.linear20);
		linear21 = findViewById(R.id.linear21);
		linear22 = findViewById(R.id.linear22);
		linear23 = findViewById(R.id.linear23);
		linear24 = findViewById(R.id.linear24);
		linear25 = findViewById(R.id.linear25);
		linear26 = findViewById(R.id.linear26);
		linear27 = findViewById(R.id.linear27);
		linear28 = findViewById(R.id.linear28);
		linear29 = findViewById(R.id.linear29);
		linear30 = findViewById(R.id.linear30);
		linear31 = findViewById(R.id.linear31);
		linear32 = findViewById(R.id.linear32);
		linear36 = findViewById(R.id.linear36);
		linear37 = findViewById(R.id.linear37);
		linear38 = findViewById(R.id.linear38);
		linear39 = findViewById(R.id.linear39);
		linear41 = findViewById(R.id.linear41);
		linear42 = findViewById(R.id.linear42);
		linear43 = findViewById(R.id.linear43);
		imageview11 = findViewById(R.id.imageview11);
		textview1 = findViewById(R.id.textview1);
		imageview12 = findViewById(R.id.imageview12);
		textview2 = findViewById(R.id.textview2);
		imageview13 = findViewById(R.id.imageview13);
		textview3 = findViewById(R.id.textview3);
		imageview14 = findViewById(R.id.imageview14);
		textview4 = findViewById(R.id.textview4);
		imageview15 = findViewById(R.id.imageview15);
		textview5 = findViewById(R.id.textview5);
		imageview16 = findViewById(R.id.imageview16);
		textview6 = findViewById(R.id.textview6);
		imageview17 = findViewById(R.id.imageview17);
		textview7 = findViewById(R.id.textview7);
		imageview18 = findViewById(R.id.imageview18);
		textview8 = findViewById(R.id.textview8);
		imageview19 = findViewById(R.id.imageview19);
		textview9 = findViewById(R.id.textview9);
		imageview20 = findViewById(R.id.imageview20);
		textview10 = findViewById(R.id.textview10);
		imageview21 = findViewById(R.id.imageview21);
		textview11 = findViewById(R.id.textview11);
		imageview22 = findViewById(R.id.imageview22);
		textview12 = findViewById(R.id.textview12);
		imageview23 = findViewById(R.id.imageview23);
		textview13 = findViewById(R.id.textview13);
		imageview24 = findViewById(R.id.imageview24);
		textview14 = findViewById(R.id.textview14);
		imageview25 = findViewById(R.id.imageview25);
		textview15 = findViewById(R.id.textview15);
		imageview28 = findViewById(R.id.imageview28);
		textview16 = findViewById(R.id.textview16);
		imageview27 = findViewById(R.id.imageview27);
		textview17 = findViewById(R.id.textview17);
		imageview26 = findViewById(R.id.imageview26);
		textview18 = findViewById(R.id.textview18);
		imageview29 = findViewById(R.id.imageview29);
		textview19 = findViewById(R.id.textview19);
		imageview30 = findViewById(R.id.imageview30);
		textview20 = findViewById(R.id.textview20);
		imageview31 = findViewById(R.id.imageview31);
		textview21 = findViewById(R.id.textview21);
		imageview32 = findViewById(R.id.imageview32);
		textview22 = findViewById(R.id.textview22);
	}
	
	private void initializeLogic() {
	}
	
}