package com.command.executer;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.*;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.appbar.AppBarLayout;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class TerminalActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private String url = "";
	private String name = "";
	private String path = "";
	
	private ScrollView vscroll3;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private TextView output;
	private ProgressBar progressbar1;
	private WebView webview1;
	private TextView prefix;
	private EditText input;
	private Button run;
	
	private TimerTask timer;
	private RequestNetwork requester;
	private RequestNetwork.RequestListener _requester_request_listener;
	private SharedPreferences userData;
	private TimerTask timer2;
	private Intent terminal = new Intent();
	private AlertDialog.Builder terminalDialog;
	private SharedPreferences sp;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.terminal);
		initialize(_savedInstanceState);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		vscroll3 = findViewById(R.id.vscroll3);
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		output = findViewById(R.id.output);
		progressbar1 = findViewById(R.id.progressbar1);
		webview1 = findViewById(R.id.webview1);
		webview1.getSettings().setJavaScriptEnabled(true);
		webview1.getSettings().setSupportZoom(true);
		prefix = findViewById(R.id.prefix);
		input = findViewById(R.id.input);
		run = findViewById(R.id.run);
		requester = new RequestNetwork(this);
		userData = getSharedPreferences("userType", Activity.MODE_PRIVATE);
		terminalDialog = new AlertDialog.Builder(this);
		sp = getSharedPreferences("commands", Activity.MODE_PRIVATE);
		
		webview1.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				timer2 = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								output.setText("Searching.");
								timer2 = new TimerTask() {
									@Override
									public void run() {
										runOnUiThread(new Runnable() {
											@Override
											public void run() {
												output.setText("Searching..");
											}
										});
									}
								};
								_timer.schedule(timer2, (int)(950));
								timer2 = new TimerTask() {
									@Override
									public void run() {
										runOnUiThread(new Runnable() {
											@Override
											public void run() {
												output.setText("Searching...");
											}
										});
									}
								};
								_timer.schedule(timer2, (int)(950));
							}
						});
					}
				};
				_timer.scheduleAtFixedRate(timer2, (int)(1), (int)(2500));
				input.setText("");
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				output.setText("Sucessfully! you want to continue? Y/N");
				timer2.cancel();
				run.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						if (input.getText().toString().equals("Y")) {
							output.setText("Sucessfully");
							input.setHint("input");
							webview1.setVisibility(View.VISIBLE);
							input.setText("");
						} else {
							output.setText("Action Cancelled");
							input.setHint("input");
							input.setText("");
						}
					}
				});
				super.onPageFinished(_param1, _param2);
			}
		});
		
		run.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (input.getText().toString().equals("download~ce")) {
					output.setText("put download url");
					run.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							output.setText("put download file name (must remember first)");
							url = input.getText().toString();
							input.setText("");
							run.setOnClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View _view) {
									name = input.getText().toString();
									input.setText("");
									output.setText("put a download path (dont start with /sdcard/ or /storage/emulated/0/\nexample:\nDownload/Command Executer\nspaces are allowed\nif u want to keep the current path digit 2\nif u want to change digit 1");
									run.setOnClickListener(new View.OnClickListener() {
										@Override
										public void onClick(View _view) {
											if (input.getText().toString().equals("2") || input.getText().toString().contains("2")) {
												path = userData.getString("downloadPath", "");
												run.performClick();
											}
											path = input.getText().toString();
											if (!FileUtil.isExistFile(path)) {
												FileUtil.makeDir(path);
												userData.edit().putString("downloadPath", path).commit();
											}
											if (input.getText().toString().equals("1") || input.getText().toString().contains("1")) {
												output.setText("Which path?");
												input.setText("");
											}
											run.setOnClickListener(new View.OnClickListener() {
												@Override
												public void onClick(View _view) {
													output.setText("download is now ready! click on run to start it");
													path = input.getText().toString();
													userData.edit().putString("downloadPath", path).commit();
													input.setText("");
													run.setOnClickListener(new View.OnClickListener() {
														@Override
														public void onClick(View _view) {
															try{
																DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
																
																
																request.setDescription("downloading file ".concat(name));
																request.setTitle("Terminal Admin");
																request.allowScanningByMediaScanner(); request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED); 
																
																/*	java.io.File aatv = new  java.io.File(Environment.getExternalStorageDirectory().getPath() + path);
if(!aatv.exists()){if (!aatv.mkdirs()){ Log.e("TravellerLog ::","Problem creating Image folder");}} request.setDestinationInExternalPublicDir(path,name);*/
																request.setDestinationUri(Uri.parse("file:///storage/emulated/0/" + path + name)); 
																DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
																manager.enqueue(request);
																output.setText("Downloading\n\ncant download? try using webview, digit terminal~Download (Mode:WebView)");
																timer = new TimerTask() {
																	@Override
																	public void run() {
																		runOnUiThread(new Runnable() {
																			@Override
																			public void run() {
																				output.setText("Downloading.\n\ncant download? try using webview, digit terminal~Download (Mode:WebView)");
																				timer = new TimerTask() {
																					@Override
																					public void run() {
																						runOnUiThread(new Runnable() {
																							@Override
																							public void run() {
																								output.setText("Downloading..\n\ncant download? try using webview, digit terminal~Download (Mode:WebView)");
																								timer = new TimerTask() {
																									@Override
																									public void run() {
																										runOnUiThread(new Runnable() {
																											@Override
																											public void run() {
																												output.setText("Downloading...\n\ncant download? try using webview, digit terminal~Download (Mode:WebView)");
																											}
																										});
																									}
																								};
																								_timer.schedule(timer, (int)(950));
																							}
																						});
																					}
																				};
																				_timer.schedule(timer, (int)(950));
																			}
																		});
																	}
																};
																_timer.scheduleAtFixedRate(timer, (int)(1), (int)(2500));
																terminalDialog.setTitle("Terminal Admin");
																terminalDialog.setMessage("download Started");
																terminalDialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
																	@Override
																	public void onClick(DialogInterface _dialog, int _which) {
																		
																	}
																});
																terminalDialog.create().show();
																//Notif if success
																BroadcastReceiver onComplete = new BroadcastReceiver() {
																	public void onReceive(Context ctxt, Intent intent) {
																		output.setText("download complete!");
																		timer.cancel();
																		url = "";
																		name = "";
																		path = "";
																		terminalDialog.setTitle("Terminal Admin ");
																		terminalDialog.setMessage("Download completed!");
																		terminalDialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
																			@Override
																			public void onClick(DialogInterface _dialog, int _which) {
																				
																			}
																		});
																		terminalDialog.create().show();
																		unregisterReceiver(this);
																	}};
																registerReceiver(onComplete, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
															} catch(Exception _e){
																SketchwareUtil.showMessage(getApplicationContext(), _e.toString());
															}
														}
													});
												}
											});
										}
									});
								}
							});
						}
					});
				}
				if (input.getText().toString().equals("PrivacyLeaker~intialize")) {
					if (userData.getString("userType", "").equals("terminal Advanced Admin")) {
						progressbar1.setIndeterminate(true);
						progressbar1.setVisibility(View.VISIBLE);
						input.setText("");
						requester.startRequestNetwork(RequestNetworkController.GET, "https://google.com", "", _requester_request_listener);
						timer = new TimerTask() {
							@Override
							public void run() {
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										output.setText("Checking network.");
										timer = new TimerTask() {
											@Override
											public void run() {
												runOnUiThread(new Runnable() {
													@Override
													public void run() {
														output.setText("Checking network..");
														timer = new TimerTask() {
															@Override
															public void run() {
																runOnUiThread(new Runnable() {
																	@Override
																	public void run() {
																		output.setText("Checking network...");
																	}
																});
															}
														};
														_timer.schedule(timer, (int)(950));
													}
												});
											}
										};
										_timer.schedule(timer, (int)(950));
									}
								});
							}
						};
						_timer.scheduleAtFixedRate(timer, (int)(1), (int)(2500));
					} else {
						SketchwareUtil.showMessage(getApplicationContext(), "you dont have enough permissions");
						output.setText("Error");
					}
				}
				if (input.getText().toString().equals("terminal~switchUser")) {
					output.setText("Which user?");
					run.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							if (input.getText().toString().equals("terminal~user {terminal Advanced admin}")) {
								userData.edit().putString("userType", "terminal Advanced Admin").commit();
								output.setText("switched sucessfully");
							}
						}
					});
				}
				if (input.getText().toString().equals("exit")) {
					finishAffinity();
				}
				if (input.getText().toString().equals("users~list")) {
					output.setText("list of users:\n\nnon user | cannot execute any command unless if use terminal~switchUser\n\nuser | can execute some commands and cannot execute admin commands\n\nadvanced user | same as user, but have more some few comnands\n\nadmin | can execute commands and have more permissions \n\nadvanced admin | can execute more commands than admin and have more permissions, have permissions as others\n\nmanager | can execute manager commands and below commands permissions\n\nadvanced manager | have more and more manager commands and more and more permissions, same as others have below commands permissions\n\nbelow terminal | have below terminal commands and permissions\n\nterminal | owner of the terminal and have all commands and permissions ");
				}
				if (input.getText().toString().equals("terminal~system.start")) {
					terminal.setClass(getApplicationContext(), MainActivity.class);
					startActivity(terminal);
				}
				if (input.getText().toString().equals("terminal~deleteFilePath")) {
					output.setText("enter the file path");
					input.setText("");
					run.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							if (FileUtil.isDirectory(input.getText().toString())) {
								input.setText("");
								output.setText("invalid path format");
							} else {
								if (FileUtil.isFile(input.getText().toString())) {
									FileUtil.deleteFile(input.getText().toString());
									input.setText("");
									output.setText("sucessfully!");
								}
							}
						}
					});
				}
				if (input.getText().toString().equals("terminal~Download (Mode:WebView)")) {
					sp.edit().putString("command", "system.startDownload").commit();
					terminal.setClass(getApplicationContext(), MainActivity.class);
					startActivity(terminal);
					finish();
				}
				if (run.getText().toString().equals("terminal.activateHack(kernel)")) {
					// Simulação de Bypass de Kernel (Local)
					final String cmd_input = input.getText().toString();
					output.setText("Checking system vulnerability...");
					
					new android.os.Handler().postDelayed(new Runnable() {
						@Override
						public void run() {
							output.setText("Vulnerability found in Protocol 2+1\nStarting buffer overflow...");
							
							new android.os.Handler().postDelayed(new Runnable() {
								@Override
								public void run() {
									output.append("\n[####------] 40%");
									
									new android.os.Handler().postDelayed(new Runnable() {
										@Override
										public void run() {
											output.append("\n[########--] 80%");
											
											new android.os.Handler().postDelayed(new Runnable() {
												@Override
												public void run() {
													output.setText("ROOT ACCESS GRANTED\nWelcome, Anonymous User.");
													input.setText("");
												}
											}, 1200);
										}
									}, 800);
								}
							}, 1000);
						}
					}, 1500);
					
				}
				if (run.getText().toString().equals("terminal.activateHack(sniffing)")) {
					// Simulação de Sniffing de Dados do Grupo D
					final String[] fake_data = {
						"PKT_01: SOURCE=127.0.0.1 DEST=VIRTUAL_NODE",
						"PKT_02: DATA_HEX=0x2+1_0x2+1_0x2+1",
						"PKT_03: STATUS=INTERCEPTED",
						"LOG: User preference identified: Group B"
					};
					
					final Timer sniffer = new Timer();
					sniffer.scheduleAtFixedRate(new TimerTask() {
						int i = 0;
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									if (i < fake_data.length) {
										output.append("\n" + fake_data[i]);
										i++;
									} else {
										output.append("\n\nExtraction Complete. Zero bits sent to modem.");
										sniffer.cancel();
									}
								}
							});
						}
					}, 0, 900);
					
				}
			}
		});
		
		_requester_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				timer.cancel();
				output.setText("Network Connected");
				progressbar1.setVisibility(View.GONE);
				SketchwareUtil.showMessage(getApplicationContext(), "Search for images");
				input.setHint("search for a people image");
				run.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						if (input.getHint().toString().equals("search for a people image")) {
							if (input.getText().toString().contains("https://") || input.getText().toString().contains("http://")) {
								webview1.loadUrl(input.getText().toString());
							}
							else {
								webview1.loadUrl("https://www.google.com/search?ie=UTF-8&client=ms-android-samsung&source=android-browser&q=".concat(input.getText().toString()));
							}
						}
					}
				});
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				output.setText("Connection Error");
				SketchwareUtil.showMessage(getApplicationContext(), _message);
				timer.cancel();
			}
		};
	}
	
	private void initializeLogic() {
		input.setTextIsSelectable(true);
		output.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/ecocoding.ttf"), 0);
		input.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/ecocoding.ttf"), 0);
		input.setCursorVisible(true);
		progressbar1.setVisibility(View.GONE);
		webview1.setVisibility(View.GONE);
		webview1.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
	}
	
	public void _check(final String _value, final TextView _result) {
		if (_value.equals("android:batteryLevel")) {
			BatteryManager terminalq = (BatteryManager)getSystemService(BATTERY_SERVICE);
			int terminalw = terminalq.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
			String terminale = Integer.toString(terminalw);
			_result.setText(terminale);
		}
	}
	
}